import React from 'react';
import { NavLink } from 'react-router-dom';
import { useAppContext } from '@/src/store/AppContext';
import { 
  LayoutDashboard, 
  Package, 
  ShoppingCart, 
  Truck, 
  Users, 
  FileText, 
  Settings,
  Box,
  CreditCard,
  BarChart3
} from 'lucide-react';
import { cn } from '@/src/lib/utils';

export function Sidebar() {
  const { role } = useAppContext();

  const navItems = [
    { name: 'Dashboard', path: '/', icon: LayoutDashboard, roles: ['Boss', 'Warehouse', 'Logistics', 'Agent', 'Finance', 'Procurement'] },
    { name: 'Orders', path: '/orders', icon: ShoppingCart, roles: ['Boss', 'Agent', 'Warehouse', 'Logistics', 'Finance'] },
    { name: 'Products', path: '/products', icon: Package, roles: ['Boss', 'Warehouse', 'Agent'] },
    { name: 'Raw Materials', path: '/materials', icon: Box, roles: ['Boss', 'Warehouse', 'Procurement'] },
    { name: 'Logistics', path: '/logistics', icon: Truck, roles: ['Boss', 'Logistics'] },
    { name: 'Customers', path: '/customers', icon: Users, roles: ['Boss', 'Agent', 'Finance'] },
    { name: 'Suppliers', path: '/suppliers', icon: Truck, roles: ['Boss', 'Procurement'] },
    { name: 'Invoices & Payments', path: '/finance', icon: CreditCard, roles: ['Boss', 'Finance', 'Agent'] },
    { name: 'Reports', path: '/reports', icon: BarChart3, roles: ['Boss', 'Finance'] },
    { name: 'Audit Logs', path: '/audit', icon: FileText, roles: ['Boss'] },
    { name: 'Settings', path: '/settings', icon: Settings, roles: ['Boss'] },
  ];

  const filteredNav = navItems.filter(item => item.roles.includes(role));

  return (
    <div className="w-64 bg-white border-r border-gray-200 h-screen flex flex-col fixed left-0 top-0">
      <div className="h-16 flex items-center px-6 border-b border-gray-200">
        <div className="flex items-center gap-2 text-red-600 font-bold text-xl tracking-tight">
          <div className="w-8 h-8 bg-red-600 rounded flex items-center justify-center text-white">
            L
          </div>
          LAMTEX
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto py-4">
        <nav className="space-y-1 px-3">
          {filteredNav.map((item) => (
            <NavLink
              key={item.name}
              to={item.path}
              className={({ isActive }) => cn(
                "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors",
                isActive 
                  ? "bg-red-50 text-red-700" 
                  : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
              )}
            >
              <item.icon className="w-5 h-5" />
              {item.name}
            </NavLink>
          ))}
        </nav>
      </div>

      <div className="p-4 border-t border-gray-200">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center text-gray-600 font-medium">
            {role.charAt(0)}
          </div>
          <div>
            <p className="text-sm font-medium text-gray-900">{role} User</p>
            <p className="text-xs text-gray-500">View Profile</p>
          </div>
        </div>
      </div>
    </div>
  );
}
